/*
 * Controller Interface to establish polymorphism
 * 3/30/23
 * -Dr. G
 * */

public interface Controller {
	void go();
}
