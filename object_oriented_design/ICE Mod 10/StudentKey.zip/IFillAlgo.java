
/*Basic interface to establish future polymorphism
 * 3/30/23
 * -Dr. G
 * */

public interface IFillAlgo {
	public void floodFill(int[][] screen, int m, int n, int x, int y, int prevC, int newC);

}
