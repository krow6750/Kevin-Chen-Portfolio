
/*Basic interface to establish future polymorphism
 * 3/30/23
 * -Dr. G
 * */

public interface IView {
	void update(int[][] data);
}
