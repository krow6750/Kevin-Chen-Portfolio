public class InterestChecking extends Savings {
    private Check[] checks = new Check[10];

    public InterestChecking() {
        super();
    }

    @Override
    public String getAccountType() {
        return "Interest Checking";
    }

    public InterestChecking(String name, int accountNum, double balance, double iRate) {
        super(name, accountNum, balance, iRate);
    }
}
