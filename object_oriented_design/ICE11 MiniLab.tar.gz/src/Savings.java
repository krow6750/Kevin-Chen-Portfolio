public class Savings extends Account {
    private double iRate;

    public Savings() {
        super();
        iRate = .01;
    }

    @Override
    public String getAccountType() {
        return "Savings";
    }

    public Savings(String name, int accountNum, double balance, double iRate) {
        super(name, accountNum, balance);
        this.iRate = iRate;
    }

    public Savings(double iRate) {
        super();
        this.iRate = iRate;
    }

    public void accumInterest() {
        super.incBalance(super.getBalance() * iRate);
    }

}