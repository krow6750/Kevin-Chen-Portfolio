//Mortgage is a loan with an address
public class Mortgage extends Loan implements Addressable {
    private String address;

    public Mortgage() {
        super();
        address = null;
    }

    public Mortgage(String name, int accountNum, double balance, double iRate, int len, String address) {
        super(name, accountNum, balance, iRate, len);
        this.address = address;
    }

    @Override
    public String getAccountType() {
        return "Mortgage";
    }

    public void decBalance(double amount) {
        super.decBalance(amount);
    }

    @Override
    public String getAddress() {
        return address;
    }

}
