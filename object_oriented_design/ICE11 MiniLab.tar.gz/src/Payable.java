public interface Payable {
    public void decBalance(double amount);
}
