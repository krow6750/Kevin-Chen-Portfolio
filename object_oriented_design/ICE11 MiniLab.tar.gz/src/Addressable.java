public interface Addressable {
    public String getAddress();
}
