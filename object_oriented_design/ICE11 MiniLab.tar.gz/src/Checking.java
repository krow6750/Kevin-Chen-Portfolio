public class Checking extends Account {
    private Check[] checks;

    public Checking() {
        super();
    }

    @Override
    public String getAccountType() {
        return "Checking";
    }

    public Checking(String name, int accountNum, double balance, Check[] checks) {
        super(name, accountNum, balance);
        this.checks = checks;
    }
}