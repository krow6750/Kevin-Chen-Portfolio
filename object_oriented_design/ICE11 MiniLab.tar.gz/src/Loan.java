public class Loan extends Account {
    private double iRate;
    private int len;

    public Loan() {
        super();
        iRate = 1;
        len = 12;
    }

    @Override
    public String getAccountType() {
        return "Loan";
    }

    public Loan(String name, int accountNum, double balance, double iRate, int len) {
        super(name, accountNum, balance);
        this.iRate = iRate;
        this.len = len;
    }

}
