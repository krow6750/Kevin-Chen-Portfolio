public class DepositServices {
    public void deposit(Savings account, double amount) {
        account.incBalance(amount);
    }
}