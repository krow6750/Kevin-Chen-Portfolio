public class PaymentServices {
    public void processPayment(Loan account, double amount) {
        account.decBalance(amount);
    }
}
