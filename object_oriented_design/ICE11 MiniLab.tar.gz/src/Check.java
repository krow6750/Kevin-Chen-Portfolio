public class Check {
    private int checkNum;
    private int checkAmount;
}