public interface Depositable {

    public void incBalance(double amount);

}
