public class MoneyMarket extends Savings implements Depositable {
    private int withdrawalLimit;
    private int numWidthdrawals;

    private Savings s1;

    public MoneyMarket() {
        super(.05);
        withdrawalLimit = 10;
        numWidthdrawals = 0;
    }

    public MoneyMarket(String name, int accountNum, double balance, double iRate, int withdrawalLimit) {
        super(name, accountNum, balance, iRate);
        this.withdrawalLimit = withdrawalLimit;
    }

    @Override
    public String getAccountType() {
        return "MoneyMarket";
    }

    public void decBalance(double amount) {
        super.decBalance(amount);
        numWidthdrawals++;
    }

    public void accumInterest() {
        super.accumInterest();
    }
}
