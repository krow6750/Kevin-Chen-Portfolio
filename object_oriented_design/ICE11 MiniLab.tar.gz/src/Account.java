public abstract class Account {
    private String name;
    private int accountNum;
    private double balance;

    public Account() {
        name = null;
        balance = 0;
        accountNum = 0;
    }

    public Account(String name, int accountNum, double balance) {
        this.name = name;
        this.accountNum = accountNum;
        this.balance = balance;
    }


    public double getBalance() {
        return balance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void incBalance(double amount) {
        this.balance += amount;
    }

    public void decBalance(double amount) {
        this.balance -= amount;
    }

    public void printAccount() {
        System.out.println(this);
    }

    public String toString() {
        return "Name : " + name + "\nAccount# : " + accountNum + "\nBalance : " + balance;
    }

    abstract public String getAccountType();
}