/**
 * Name: Kevin Chen
 * Assignment: Lab 8
 * Date: 04/17/2023
 * Notes: Enumeration to represent players in TicTacToe game
 */

package cs5004.tictactoe;

public enum Player {
	X,O
}
