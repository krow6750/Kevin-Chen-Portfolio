/******
 Name: Kevin Chen
 Assignment: Lab 1
 Date: 1/29/23
 Notes: Driver to generate point in each quadrant and in the origin, then test each quadrant.
 ******/

public class Driver {

    private static void test(Point point, String quadrant) {
        if (point.getQuadrant().equals(quadrant))
            System.out.println(quadrant + " test passed");
        else
            System.out.println(quadrant + " test failed");
    }

    // Create a driver
    public static void main(String[] args) {

        // generate a point in each quadrant and the origin and test them
        test(new Point(0, 0), "Origin");

        test(new Point( 1,  1), "Quadrant A");
        test(new Point(-1,  1), "Quadrant B");
        test(new Point(-1, -1), "Quadrant C");
        test(new Point( 1, -1), "Quadrant D");

        test(new Point(0, 1), "Border");
        test(new Point(5, 0), "Border");

        // Pythagoras Triples (whole a, b and c) for pretty prints
        Line l1 = new Line(3, 2, 7, -1);
        Line l2 = new Line(1, 5, 6, 17);
        Line l3 = new Line(-30, 4, 30, -7);

        System.out.println("First  segment's length: " + l1.getLength());
        System.out.println("Second segment's length: " + l2.getLength());
        System.out.println("Third  segment's length: " + l3.getLength());
    }
}
