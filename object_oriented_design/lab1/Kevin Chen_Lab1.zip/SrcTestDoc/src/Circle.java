/******
 Name: Kevin Chen
 Assignment: Lab 1
 Date: 1/29/23
 Notes: Circle class represented by a center point and a radius size.
 ******/

public class Circle {

    private Point center;
    private int radius;

    /**
     * Constructs a new Circle from the center coordinates and a radius
     *
     * @param x center's x coordinate
     * @param y center's y coordinate
     * @param radius circle's radius
     *
     * @see Circle#Circle(Point, int)
     */
    public Circle(int x, int y, int radius) {
        this(new Point(x, y), radius);
    }

    /**
     * Constructs a new Circle from the center point and a radius
     *
     * @param center the center point
     * @param radius circle's radius
     */
    public Circle(Point center, int radius) {
        this.center = center;
        this.radius = radius;
    }

    /**
     * Tells whether a point is inside the circle or not
     *
     * @param point Point to be tested
     * @return Whether the point is inside the circle
     */
    public boolean containsPoint(Point point) {
        return new Line(center, point).getLength() <= radius;
    }

    @Override public boolean equals(Object other) {
        if (this == other) return true;

        if (!(other instanceof Circle)) return false;
        Circle circle = (Circle) other;

        return circle.radius == radius && center.equals(circle.center);
    }

    @Override public String toString() {
        return String.format("(%s - %d)", center, radius);
    }
}
