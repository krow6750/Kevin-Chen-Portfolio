/******
 Name: Kevin Chen
 Assignment: Lab 1
 Date: 1/29/23
 Notes: Point Class represented by two integers x and y as the position
 ******/

public class Point {

    private int x, y;

    /**
     * Point at (0, 0)
     */
    public static final Point ORIGIN = new Point(0, 0);

    /**
     * Makes a point at (0, 0)
     * @see Point#Point(int, int)
     */
    public Point() { this(0, 0); }

    /**
     * Makes a point at the specified coordinates (will be clamped to [-99; 99])
     * @param x X coordinate
     * @param y Y coordinate
     */
    public Point(int x, int y) {
        setX(x); setY(y);
    }

    private static int clamp(int n) {
        return Math.max(-99, Math.min(99, n));
    }

    /**
     * Returns the X coordinate of the point
     * @return X coordinate
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the Y coordinate of the point
     * @return Y coordinate
     */
    public int getY() {
        return y;
    }

    /**
     * Sets the X coordinate <p>
     * Clamps it to [-99, 99]
     * @param x the new X coordinate (will be clamped between [-99; 99])
     */
    public void setX(int x) {
        this.x = clamp(x);
    }

    /**
     * Sets the Y coordinate <p>
     * Clamps it to [-99, 99]
     * @param y the new Y coordinate (will be clamped between [-99; 99])
     */
    public void setY(int y) {
        this.y = clamp(y);
    }

    /**
     * Returns the quadrant the point lies in
     * <p>
     * The different variants are:
     * A: (+x, +y), B: (-x, +y), C: (-x, -y), D: (+x, -y)
     * Border: (x, 0) || (0, y), Origin: (0, 0)
     * @return The quadrant the point lies in
     */
    public String getQuadrant() {
        if (x == 0 || y == 0)
            if (x == y) return "Origin";
            else return "Border";
        if (0 < y)
            if (0 < x) return "Quadrant A";
            else return "Quadrant B";
        else
            if (x < 0) return "Quadrant C";
            else return "Quadrant D";
    }

    /**
     * Prints the point
     */
    public void printPoint() {
        System.out.println(toString());
    }

    @Override public boolean equals(Object other) {
        if (this == other) return true;

        if (!(other instanceof Point)) return false;
        Point point = (Point) other;

        return this.x == point.x && this.y == point.y;
    }

    @Override public String toString() {
        return String.format("(%d, %d)", x, y);
    }
}
