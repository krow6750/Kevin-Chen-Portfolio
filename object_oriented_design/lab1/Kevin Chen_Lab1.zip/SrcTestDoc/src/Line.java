/******
 Name: Kevin Chen
 Assignment: Lab 1
 Date: 1/29/23
 Notes: Line Class represented by two points as the origin and end
 ******/

public class Line {

    private final Point p1, p2;

    /**
     * Creates a segment going from the origin to the origin
     * @see Line#Segment(Point, Point)
     */
    public Line() { this(Point.ORIGIN, Point.ORIGIN); }

    /**
     * Creates a segment from the coordinates of two points
     * @see Line#Segment(Point, Point)
     */
    public Line(int ox, int oy, int ex, int ey) { this(new Point(ox, oy), new Point(ex, ey)); }

    /**
     * Returns a segment going from the specified point to the other point
     */
    public Line(Point origin, Point end) {
        this.p1 = origin;
        this.p2 = end;
    }

    /**
     * Returns the first point of the segment
     * @return First Point
     */
    public Point getP1() {
        return p1;
    }

    /**
     * Returns the second point of the segment
     * @return Second Point
     */
    public Point getP2() {
        return p2;
    }

    /**
     * Computes and returns the distance between the two points
     * @return Length of the segment
     */
    public double getLength() {
        double dx = p2.getX() - p1.getX();
        double dy = p2.getY() - p1.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }


    /**
     * Takes the cross product of the given point against the two segment points
     *
     * @param po Point to take the cross product against
     * @return The cross product between the three points
     */
    public int crossProduct(Point po) {
        return (p2.getX() - p1.getX()) * (po.getY() - p1.getY()) - (p2.getY() - p1.getY()) * (po.getX() - p1.getX());
    }

    private int sign(int n) {
        return Math.max(-1, Math.min(n, 1));
    }

    private boolean pointBox(Point point) {
        return (point.getX() <= Math.max(p1.getX(), p2.getX()) && point.getX() >= Math.min(p1.getX(), p2.getX()) &&
                point.getY() <= Math.max(p1.getY(), p2.getY()) && point.getY() >= Math.min(p1.getY(), p2.getY()));
    }

    /**
     * This method will return the slope of the line as in mx+p <p>
     * NaN will be used for invalid slopes (for the case of vertical segments)
     *
     * @return the slope of the line
     */
    public double getSlope() {
        int dx = p2.getX() - p1.getX();
        if (dx == 0) return Double.NaN;
        int dy = p2.getY() - p1.getY();

        return dy / (double) dx;
    }

    /**
     * This method checks whether two segments are intersection or not
     * <p>
     * It first uses the cross product to see if the points of the other segment are on either side of the current one
     * We repeat the same method on the current points against the other segment
     * <p>
     * Then we must check for the edge cases, colinearity
     * Since the cross product being 0 means that the three points within the product are colinear
     * We can simply use a bounding box check to figure out if it lies or not on the segment
     * <p>
     * If all of those checks fail, it means that the two segments aren't intersecting
     *
     * @param other Other segment to be checked
     * @return Whether the segment intersects with the provided other
     */
    public boolean intersects(Line other) {
        int s1 = crossProduct(other.getP1()), s2 = crossProduct(other.getP2());
        int c1 = other.crossProduct(getP1()), c2 = other.crossProduct(getP2());

        // Checking if the point of the other segment are on opposite sides of our segment
        // as well as checking the opposite, if our points are on opposite sides of the other
        if ((sign(s1) != sign(s2)) && (sign(c1) != sign(c2))) return true;

        // Co-linearity requires special handling
        // given the point being colinear, we can simply use a bounding box check to see if it resides within the line
        return ((s1 == 0 && pointBox(other.getP1())) || (s2 == 0 && pointBox(other.getP2()))
                || (c1 == 0 && other.pointBox(p1)) || (c2 == 0 && other.pointBox(p2)));
    }

    /**
     * Prints the line by printing the two points
     */
    public void printLine() {
        System.out.println(toString());
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof Line)) return false;

        Line line = (Line) other;
        return ((p1.equals(line.getP1()) && p2.equals(line.getP2())) ||
                (p1.equals(line.getP2()) && p2.equals(line.getP1())));
    }

    @Override
    public String toString() {
        return String.format("[%s; %s]", p1, p2);
    }
}
