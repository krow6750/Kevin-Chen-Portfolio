/****** 
Name: Kevin Chen
 Assignment: Lab 1
 Date: 1/29/23
 Notes: LineTester tests
 ******/

import org.junit.Test;

import static org.junit.Assert.*;

public class LineTest {

    Line l1 = new Line(1, 1, 5, 3),
            l2 = new Line(1, 5, 2, 2),
            l3 = new Line(1, 4, 5, 2),
            l4 = new Line(3, 2, 9, 5),
            l5 = new Line(7, 1, 9, 0),
            l6 = new Line(7, 1, 7, 4),
            l7 = new Line(9, 0, 7, 1);

    Circle c1 = new Circle(4, 4, 3);

    // Also covers point equality, used within segment equality
    @Test public void equalityTest() {
        assertNotEquals(l1, l7);
        assertNotEquals(l7, l1);

        assertEquals(l7, l5);
        assertEquals(l5, l7);

        assertNotEquals(l1, l5);
        assertNotEquals(l5, l1);

        assertEquals(l6, l6);
        assertNotEquals(l1, null);
    }

    @Test public void intersectTest() {
        assertFalse(l1.intersects(l2));
        assertFalse(l2.intersects(l1));

        assertTrue(l1.intersects(l3));
        assertTrue(l3.intersects(l1));

        assertTrue(l2.intersects(l3));
        assertTrue(l3.intersects(l2));

        assertTrue(l4.intersects(l1));
        assertTrue(l1.intersects(l4));

        assertFalse(l3.intersects(l5));
        assertFalse(l5.intersects(l3));

        assertTrue(l6.intersects(l5));
        assertTrue(l5.intersects(l6));

        assertTrue(l6.intersects(l4));
        assertTrue(l4.intersects(l6));
    }

    @Test public void toStringTest() {
        assertEquals(l1.toString(), "[(1, 1); (5, 3)]");
        assertEquals(l7.toString(), "[(9, 0); (7, 1)]");
        assertEquals(c1.toString(), "((4, 4) - 3)");
    }

    @Test public void slopeTest() {
        assertEquals(l1.getSlope(),  1./2., 0);
        assertEquals(l5.getSlope(), -1./2., 0);
        assertTrue(Double.isNaN(l6.getSlope()));
    }

    @Test public void circleTest() {
        assertEquals(c1, new Circle(4, 4, 3));
        assertNotEquals(c1, new Circle(4, 4, 4));
        assertNotEquals(c1, new Circle(4, 5, 4));

        assertTrue(c1.containsPoint(l4.getP1()));
        assertFalse(c1.containsPoint(l7.getP2()));
    }

}
