/******
Name: Kevin Chen 
Assignment: Lab 0
Date: 1/22/23 
Notes: A JUnit test class for the Person class.
******/

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * JUnit test class for the Person class
 */
public class PersonTest {

  private Person john;

  /**
   * Prepares the person instance for testing
   */
  @Before
  public void setUp() {
    john = new Person("John", "Doe", 1945);
  }

  /**
   * Tests the first name
   */
  @Test
  public void testFirstName() {
    assertEquals("John", john.getFirstName());
  }

  /**
   * Tests the last name
   */
  @Test
  public void testLastName() {
    assertEquals("Doe", john.getLastName());
  }

  /**
   * Tests the year of birth of the person
   */
  @Test
  public void testYearOfBirth() {
    assertEquals(1945, john.getYearOfBirth());
  }

}
