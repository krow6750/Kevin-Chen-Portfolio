/******
 Name: Kevin Chen
 Assignment: Lab 0
 Date: 1/22/23
 Notes: A JUnit test class for the Book class.
 ******/

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * JUnit test class for the Book class
 */
public class BookTest {

	private Book hamlet;

	/**
	 * Prepares the book instance we will be testing
	 */
	@Before public void setUp() {
		hamlet = new Book("Hamlet", new Person("William", "Shakespeare", 1564), 10);
	}

	/**
	 * Tests the title of the book
	 */
	@Test public void testTitle() {
		assertEquals("Hamlet", hamlet.getTitle());
	}

	/**
	 * Tests the author of the book
	 * Refer to the PersonTest tests
	 */
	@Test public void testAuthor() {
		Person author = hamlet.getAuthor();
		assertEquals("William", author.getFirstName());
		assertEquals("Shakespeare", author.getLastName());
		assertEquals(1564, author.getYearOfBirth());
	}

	/**
	 * Tests the price of the book
	 */
	@Test public void testPrice() {
		assertEquals(10, hamlet.getPrice(), 0);
	}
}
