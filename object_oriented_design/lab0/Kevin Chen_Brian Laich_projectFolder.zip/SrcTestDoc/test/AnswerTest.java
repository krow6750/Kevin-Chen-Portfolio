/******
 Name: Kevin Chen
 Assignment: Lab 0
 Date: 1/22/23
 Notes: A JUnit test class for the Answer and Question classes.
 ******/

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * JUnit class to test Answer and Question classes
 */
public class AnswerTest {

    private Question java = new Question("Do you like Java ?", "Yes");
    private Answer unjava = new Answer(java, "No");

    @Test public void getQuestion() {
        assertEquals(java.getPrompt(), unjava.getQuestion());
        assertEquals(unjava.getQuestion(), "Do you like Java ?");
    }

    @Test public void getAnswer() {
        assertEquals(java.getAnswer(), unjava.getAnswer());
        assertEquals(unjava.getAnswer(), "Yes");
    }

    @Test public void getAttempt() {
        assertEquals(unjava.getAttempt(), "No");
    }

    @Test public void isCorrect() {
        assertFalse(unjava.isCorrect());
    }
}