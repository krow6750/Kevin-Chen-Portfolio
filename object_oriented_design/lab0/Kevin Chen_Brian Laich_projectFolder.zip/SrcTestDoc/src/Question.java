/******
 Name: Kevin Chen
 Assignment: Lab 0
 Date: 1/22/23
 Notes: This class asks a question.
 ******/

public class Question {

    private String prompt, answer;

    /**
     * Construct a Question object.
     *
     * @param prompt the question's prompt to be presented
     * @param answer the correct answer to the question
     */
    public Question(String prompt, String answer) {
        this.prompt = prompt;
        this.answer = answer;
    }

    /**
     * Getter for the Prompt
     *
     * @return Question's Prompt
     */
    public String getPrompt() {
        return prompt;
    }

    /**
     * Getter for the Answer
     *
     * @return Question's Answer
     */
    public String getAnswer() {
        return answer;
    }
}
