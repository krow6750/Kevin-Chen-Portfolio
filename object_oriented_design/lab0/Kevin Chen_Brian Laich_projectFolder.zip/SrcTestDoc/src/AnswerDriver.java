/******
 Name: Kevin Chen
 Assignment: Lab 0
 Date: 1/22/23
 Notes: A driver class to show Question and Answer usage
 ******/

import java.util.Scanner;

/**
 * Driver class to demonstrate Answer's capabilities
 */
public class AnswerDriver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Question java = new Question("Do you like Java ?", "y");

        System.out.println(java.getPrompt());
        System.out.print("Yes / No ? ");

        String answer = input.nextLine().toLowerCase().substring(0, 1);
        Answer question = new Answer(java, answer);

        if (question.isCorrect()) {
            System.out.println("Java is indeed cool");
        } else {
            System.out.println("That's uncool :(");
        }
    }
}
