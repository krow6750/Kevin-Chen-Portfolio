/******
 Name: Kevin Chen
 Assignment: Lab 0
 Date: 1/22/23
 Notes: This class attempts to answer a question.
 ******/

public class Answer {

    private Question question;
    private String attempt;

    /**
     * Construct an Answer object, attempting to answer a Question
     *
     * @param question the question being answered
     * @param attempt the attempted answer to the question
     */
    public Answer(Question question, String attempt) {
        this.question = question;
        this.attempt = attempt;
    }

    /**
     * Getter for the question's prompt the answer answers to
     *
     * @return The Question being answered
     */
    public String getQuestion() {
        return question.getPrompt();
    }

    /**
     * Getter for the question's answer
     *
     * @return The Question's true answer
     */
    public String getAnswer() {
        return question.getAnswer();
    }

    /**
     * Getter for the question the answer answers
     *
     * @return The Question being answered
     */
    public String getAttempt() {
        return attempt;
    }

    /**
     * Getter for the question the answer answers
     *
     * @return The Question being answered
     */
    public boolean isCorrect() {
        return question.getAnswer().equals(attempt);
    }
}
