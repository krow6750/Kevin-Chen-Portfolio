# Import required libraries
import simulus
import numpy as np
import random


# Define a class to keep track of queue statistics
# The __init__ method initializes all the statistics variables to 0.
class QueueStats:
    def __init__(self):
        self.numInSystem = 0
        self.numArrivals = 0
        self.numDepartures = 0
        self.areaNumInSystem = 0.0
        self.areaNumInQueue = 0.0
        self.areaServerStatus = 0.0
        self.timeLastEvent = 0.0

    # The update method updates the statistics variables given the current system state.
    # numInSystem is the number of entities in the system.
    # timeNow is the current simulation time.
    # timeLastEvent is the time of the last event.
    def update(self, numInSystem, timeNow, timeLastEvent):
        # Update queue statistics
        timeDelta = timeNow - self.timeLastEvent
        self.areaNumInSystem += numInSystem * timeDelta
        self.areaNumInQueue += max(0, numInSystem - 1) * timeDelta
        self.areaServerStatus += (1 if numInSystem > 0 else 0) * timeDelta
        self.numInSystem = numInSystem
        self.timeLastEvent = timeLastEvent
    # The report method prints out the statistics at the end of the simulation.
    # Tmax is the maximum time of the simulation.
    def report(self, Tmax):
        # Print queue statistics report
        print("# Arrivals:", self.numArrivals)
        print("# Completions:", self.numDepartures)
        print("# in system @ end:", self.numInSystem)
        print("TA # in system:", self.areaNumInSystem / Tmax)
        print("TA # in queue:", self.areaNumInQueue / Tmax)
        print("utilization:", self.areaServerStatus / Tmax)

# Create an instance of the QueueStats class
queueStats = QueueStats()

# Define an arrival event
# The arrival function simulates an entity arriving at the system.
# queueStats.numArrivals is incremented.
# If the system is empty, the entity is served immediately.
# If the system is not empty and the maximum arrivals have not been reached, the entity is added to the queue.
# If the maximum arrivals have been reached, no more entities will arrive, so no completion event is scheduled.
def arrival():
    # Increment the number of arrivals
    queueStats.numArrivals += 1
     # If the queue is empty, start service immediately
    if queueStats.numInSystem == 0:
        queueStats.areaNumInQueue += queueStats.numInSystem * (sim.now - queueStats.timeLastEvent)
        queueStats.areaServerStatus += (sim.now - queueStats.timeLastEvent)
        serviceTime = getService()
        sim.sleep(until = sim.now + serviceTime)
        queueStats.numInSystem += 1
        queueStats.timeLastEvent = sim.now
    # If the queue is not empty, wait in the queue
    elif queueStats.numArrivals < maxArrivals:
        queueStats.areaNumInQueue += (queueStats.numInSystem - 1) * (sim.now - queueStats.timeLastEvent)
        queueStats.timeLastEvent = sim.now
        serviceTime = getService()
        sim.sleep(until = sim.now + serviceTime)
        queueStats.numInSystem += 1
    if(sim.now < maxArrivals):
        completion()
# Call completion event
def completion():
    # Increment the number of departures
    queueStats.numDepartures += 1
     # Update queue statistics
    queueStats.areaNumInSystem += queueStats.numInSystem * (sim.now - queueStats.timeLastEvent)
    queueStats.areaServerStatus += (sim.now - queueStats.timeLastEvent)
    queueStats.timeLastEvent = sim.now
    queueStats.numInSystem -= 1
    # If there are more customers waiting, start service for the next customer
    if queueStats.numInSystem > 0:
        serviceTime = getService()
        sim.sleep(until = sim.now + serviceTime)

# Define a function to get interarrival time
# Generate an interarrival time drawn from an exponential distribution with a mean of 5
def getInterarrival():
    return np.random.exponential(1/5)  # mean interarrival time of 5

# Generate a service time drawn from an exponential distribution with a mean of 4
def getService():
    return np.random.exponential(1/4)  # mean service time of 4

sim = simulus.simulator()
maxArrivals = 10000
arrivals = random.randint(1000, 10000)

def start():
    for i in range(arrivals):
        arrival()
        sim.sleep(getInterarrival())
        if (i == arrivals - 1):
            queueStats.report(maxArrivals)

sim.process(start)
sim.run()

