// Your Name Here
// Date Here
// CS5008 Lab03
//
// Implement your cycle count tool here.

